# Readme
The code I wrote in this assignment are in the ipynb files. The coding questions (1, 3, and 4) are all stored in Q<# question>.ipynb correspondingly. The codes can be run directly; however, the generated files will appear in the main folder, not the Q<# question>_prod folder.

The relevant plotting, figures, and TXT files are in the corresponding _prod folders, respectively.